import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BankAccountAcceptanceTest {
    
    @Test
    public void testUserStory1_CreateAccount() {
        // User Story: As a customer, I want to create a new bank account
        BankAccount account = new BankAccount("123", "John Doe");
        
        assertNotNull(account);
        assertEquals("123", account.getAccountNumber());
        assertEquals("John Doe", account.getAccountHolder());
        assertEquals(0.0, account.getBalance());
    }

    @Test
    public void testUserStory2_ManageMoney() {
        // User Story: As a customer, I want to deposit and withdraw money
        BankAccount account = new BankAccount("123", "John Doe");
        
        // Deposit initial amount
        account.deposit(1000.0);
        assertEquals(1000.0, account.getBalance());
        
        // Withdraw some money
        account.withdraw(300.0);
        assertEquals(700.0, account.getBalance());
        
        // Ensure can't withdraw more than balance
        assertThrows(IllegalArgumentException.class, () -> account.withdraw(1000.0));
    }
} 