import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BankAccountUnitTest {
    
    @Test
    public void testDeposit() {
        BankAccount account = new BankAccount("123", "John Doe");
        account.deposit(100.0);
        assertEquals(100.0, account.getBalance());
    }

    @Test
    public void testWithdraw() {
        BankAccount account = new BankAccount("123", "John Doe");
        account.deposit(100.0);
        account.withdraw(50.0);
        assertEquals(50.0, account.getBalance());
    }

    @Test
    public void testNegativeDeposit() {
        BankAccount account = new BankAccount("123", "John Doe");
        assertThrows(IllegalArgumentException.class, () -> account.deposit(-100.0));
    }

    @Test
    public void testInsufficientFunds() {
        BankAccount account = new BankAccount("123", "John Doe");
        assertThrows(IllegalArgumentException.class, () -> account.withdraw(100.0));
    }
} 