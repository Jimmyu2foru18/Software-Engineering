import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BankAccountIntegrationTest {
    
    @Test
    public void testMultipleTransactions() {
        BankAccount account = new BankAccount("123", "John Doe");
        
        // Test a series of deposits and withdrawals
        account.deposit(1000.0);
        account.withdraw(200.0);
        account.deposit(50.0);
        account.withdraw(300.0);
        
        assertEquals(550.0, account.getBalance());
    }

    @Test
    public void testAccountInformation() {
        BankAccount account = new BankAccount("123", "John Doe");
        
        // Test if account information and balance are correctly maintained
        account.deposit(500.0);
        assertEquals("123", account.getAccountNumber());
        assertEquals("John Doe", account.getAccountHolder());
        assertEquals(500.0, account.getBalance());
    }
} 