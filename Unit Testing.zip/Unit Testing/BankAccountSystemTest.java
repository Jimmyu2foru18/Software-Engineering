import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BankAccountSystemTest {
    
    @Test
    public void testCompleteWorkflow() {
        // Create multiple accounts and test interactions
        BankAccount account1 = new BankAccount("123", "John Doe");
        BankAccount account2 = new BankAccount("456", "Jane Smith");
        
        // Simulate a complete banking workflow
        account1.deposit(1000.0);
        account2.deposit(500.0);
        
        account1.withdraw(300.0);
        account2.deposit(300.0);
        
        assertEquals(700.0, account1.getBalance());
        assertEquals(800.0, account2.getBalance());
    }

    @Test
    public void testSystemLimits() {
        BankAccount account = new BankAccount("123", "John Doe");
        
        // Test system boundaries
        account.deposit(Double.MAX_VALUE / 2);
        assertTrue(account.getBalance() > 0);
        
        assertThrows(IllegalArgumentException.class, () -> account.withdraw(Double.MAX_VALUE));
    }
} 