// server.js
require('dotenv').config();
const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const bodyParser = require('body-parser');
const cors = require('cors');
const multer = require('multer');

const app = express();
app.use(bodyParser.json());
app.use(cors());
app.use(express.static('public')); // Serve static files from the 'public' directory

// Database connection
const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: 'social_network'
});

db.connect((err) => {
    if (err) throw err;
    console.log('Database connected');
});

// Routes (simplified)
app.post('/register', async (req, res) => {
    // Registration logic here
});

app.post('/login', async (req, res) => {
    // Login logic here
});

app.post('/update-profile', async (req, res) => {
    // Profile update logic here
});

app.listen(3000, () => {
    console.log('Server running on port 3000');
});
