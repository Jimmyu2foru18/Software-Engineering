@echo off
echo Compiling Java files...

REM Create bin directory if it doesn't exist
if not exist bin mkdir bin

REM Compile all Java files
javac -d bin src/main/java/com/ga/model/*.java src/main/java/com/ga/*.java

echo Compilation completed.
pause 