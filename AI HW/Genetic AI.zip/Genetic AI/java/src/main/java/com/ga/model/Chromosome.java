package com.ga.model;

import java.util.Random;

public class Chromosome {
    private int[][] genes;
    private int M;
    private int N;
    private Double fitness;
    private static final Random random = new Random();

    public Chromosome(int M, int N) {
        this.M = M;
        this.N = N;
        this.genes = initializeGenes();
    }

    public Chromosome(int M, int N, int[][] genes) {
        this.M = M;
        this.N = N;
        this.genes = new int[M][N];
        for (int i = 0; i < M; i++) {
            System.arraycopy(genes[i], 0, this.genes[i], 0, N);
        }
    }

    private int[][] initializeGenes() {
        // Initialize with numbers 1 to M*N in random order
        int[] values = new int[M * N];
        for (int i = 0; i < M * N; i++) {
            values[i] = i + 1;
        }
        
        // Fisher-Yates shuffle
        for (int i = values.length - 1; i > 0; i--) {
            int j = random.nextInt(i + 1);
            int temp = values[i];
            values[i] = values[j];
            values[j] = temp;
        }

        // Convert to MxN matrix
        int[][] result = new int[M][N];
        int index = 0;
        for (int i = 0; i < M; i++) {
            for (int j = 0; j < N; j++) {
                result[i][j] = values[index++];
            }
        }
        return result;
    }

    public double calculateFitness() {
        if (fitness != null) {
            return fitness;
        }

        double totalCost = 0;
        // Calculate horizontal differences
        for (int i = 0; i < M; i++) {
            for (int j = 0; j < N - 1; j++) {
                totalCost += Math.abs(genes[i][j] - genes[i][j + 1]);
            }
        }
        // Calculate vertical differences
        for (int i = 0; i < M - 1; i++) {
            for (int j = 0; j < N; j++) {
                totalCost += Math.abs(genes[i][j] - genes[i + 1][j]);
            }
        }
        fitness = totalCost;
        return totalCost;
    }

    public void saveToFile(String filename) {
        try (java.io.PrintWriter writer = new java.io.PrintWriter(filename)) {
            for (int i = 0; i < M; i++) {
                StringBuilder line = new StringBuilder();
                for (int j = 0; j < N; j++) {
                    line.append(genes[i][j]);
                    if (j < N - 1) {
                        line.append(",");
                    }
                }
                writer.println(line.toString());
            }
        } catch (java.io.FileNotFoundException e) {
            System.err.println("Error saving solution: " + e.getMessage());
        }
    }

    public double getFitness() {
        return calculateFitness();
    }

    public int[][] getGenes() {
        return genes;
    }

    public void setGenes(int[][] newGenes) {
        this.genes = newGenes;
        this.fitness = null;
    }
}
