package com.ga.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Population {
    private List<Chromosome> chromosomes;
    private int size;
    private int M;
    private int N;
    private static final Random random = new Random();
    private static final double MUTATION_RATE = 0.1;

    public Population(int size, int M, int N) {
        this.size = size;
        this.M = M;
        this.N = N;
        initializePopulation();
    }

    private void initializePopulation() {
        chromosomes = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            chromosomes.add(new Chromosome(M, N));
        }
    }

    public void evolve() {
        List<Chromosome> newPopulation = new ArrayList<>();
        
        // Keep the best chromosome (elitism)
        Chromosome best = getBestChromosome();
        newPopulation.add(new Chromosome(M, N, best.getGenes()));
        
        // Create new chromosomes through selection and crossover
        while (newPopulation.size() < size) {
            // Tournament selection
            Chromosome parent1 = tournamentSelect();
            Chromosome parent2 = tournamentSelect();
            
            // Crossover
            Chromosome child = crossover(parent1, parent2);
            
            // Mutation
            if (random.nextDouble() < MUTATION_RATE) {
                mutate(child);
            }
            
            newPopulation.add(child);
        }
        
        chromosomes = newPopulation;
    }

    private Chromosome tournamentSelect() {
        int tournamentSize = 3;
        Chromosome best = chromosomes.get(random.nextInt(size));
        
        for (int i = 1; i < tournamentSize; i++) {
            Chromosome challenger = chromosomes.get(random.nextInt(size));
            if (challenger.getFitness() < best.getFitness()) {
                best = challenger;
            }
        }
        
        return best;
    }

    private Chromosome crossover(Chromosome parent1, Chromosome parent2) {
        int[][] p1Genes = parent1.getGenes();
        int[][] p2Genes = parent2.getGenes();
        int[][] childGenes = new int[M][N];
        boolean[] used = new boolean[M * N + 1];
        
        // Copy first half from parent1
        int midpoint = (M * N) / 2;
        int count = 0;
        outer: for (int i = 0; i < M; i++) {
            for (int j = 0; j < N; j++) {
                if (count >= midpoint) break outer;
                childGenes[i][j] = p1Genes[i][j];
                used[p1Genes[i][j]] = true;
                count++;
            }
        }
        
        // Fill remaining positions with unused numbers from parent2
        for (int i = 0; i < M; i++) {
            for (int j = 0; j < N; j++) {
                if (childGenes[i][j] == 0) {  // Position not yet filled
                    for (int[] row : p2Genes) {
                        for (int num : row) {
                            if (!used[num]) {
                                childGenes[i][j] = num;
                                used[num] = true;
                                break;
                            }
                        }
                        if (childGenes[i][j] != 0) break;
                    }
                }
            }
        }
        
        return new Chromosome(M, N, childGenes);
    }

    private void mutate(Chromosome chromosome) {
        int[][] genes = chromosome.getGenes();
        
        // Swap two random positions
        int i1 = random.nextInt(M);
        int j1 = random.nextInt(N);
        int i2 = random.nextInt(M);
        int j2 = random.nextInt(N);
        
        int temp = genes[i1][j1];
        genes[i1][j1] = genes[i2][j2];
        genes[i2][j2] = temp;
        
        chromosome.setGenes(genes);
    }

    public Chromosome getBestChromosome() {
        Chromosome best = chromosomes.get(0);
        for (int i = 1; i < size; i++) {
            if (chromosomes.get(i).getFitness() < best.getFitness()) {
                best = chromosomes.get(i);
            }
        }
        return best;
    }
}
