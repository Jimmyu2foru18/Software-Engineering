package com.ga;

import com.ga.model.Population;
import com.ga.model.Chromosome;
import javax.swing.*;
import java.awt.*;
import java.io.*;

public class Main {
    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Usage: java GeneticAlgorithm M N");
            System.exit(1);
        }

        try {
            int M = Integer.parseInt(args[0]);
            int N = Integer.parseInt(args[1]);
            
            // Initialize population
            int populationSize = 100;
            Population population = new Population(populationSize, M, N);
            
            // Create visualization frame
            JFrame frame = new JFrame("Genetic Algorithm");
            SolutionPanel solutionPanel = new SolutionPanel(M, N);
            frame.add(solutionPanel);
            frame.setSize(600, 400);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
            
            // Evolution loop
            int maxGenerations = 1000;
            Chromosome bestSolution = null;
            double bestFitness = Double.POSITIVE_INFINITY;
            
            for (int generation = 0; generation < maxGenerations; generation++) {
                population.evolve();
                Chromosome currentBest = population.getBestChromosome();
                double currentFitness = currentBest.getFitness();
                
                // Update visualization
                solutionPanel.updateSolution(currentBest.getGenes(), currentFitness, generation);
                frame.repaint();
                
                if (currentFitness < bestFitness) {
                    bestFitness = currentFitness;
                    bestSolution = currentBest;
                    System.out.println("Generation " + generation + ": Cost = " + bestFitness);
                }
            }
            
            // Save solution and cost
            if (bestSolution != null) {
                bestSolution.saveToFile("solution_1.txt");
                try (PrintWriter writer = new PrintWriter("solution_cost.txt")) {
                    writer.println(bestFitness);
                }
            }
            
        } catch (NumberFormatException e) {
            System.out.println("Invalid input: M and N must be integers");
            System.exit(1);
        } catch (IOException e) {
            System.out.println("Error saving results: " + e.getMessage());
            System.exit(1);
        }
    }
}

class SolutionPanel extends JPanel {
    private int[][] solution;
    private double cost;
    private int M;
    private int N;
    private int generation;
    private long startTime;
    
    public SolutionPanel(int M, int N) {
        this.M = M;
        this.N = N;
        this.generation = 0;
        this.startTime = System.currentTimeMillis();
        setPreferredSize(new Dimension(800, 600));
    }
    
    public void updateSolution(int[][] solution, double cost, int generation) {
        this.solution = solution;
        this.cost = cost;
        this.generation = generation;
        repaint();
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (solution == null) return;
        
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Calculate cell dimensions
        int padding = 50;
        int availWidth = getWidth() - 2 * padding;
        int availHeight = getHeight() - 3 * padding;
        int cellWidth = availWidth / N;
        int cellHeight = availHeight / M;
        
        // Draw title
        g2d.setFont(new Font("Arial", Font.BOLD, 16));
        g2d.drawString("Genetic Algorithm Visualization", padding, 30);
        
        // Draw grid
        g2d.setFont(new Font("Arial", Font.PLAIN, 12));
        for (int i = 0; i < M; i++) {
            for (int j = 0; j < N; j++) {
                int x = padding + j * cellWidth;
                int y = padding + i * cellHeight;
                
                // Draw cell
                g2d.setColor(Color.WHITE);
                g2d.fillRect(x, y, cellWidth, cellHeight);
                g2d.setColor(Color.BLACK);
                g2d.drawRect(x, y, cellWidth, cellHeight);
                
                // Draw number
                String num = String.valueOf(solution[i][j]);
                FontMetrics fm = g2d.getFontMetrics();
                int numX = x + (cellWidth - fm.stringWidth(num)) / 2;
                int numY = y + (cellHeight + fm.getAscent()) / 2;
                g2d.drawString(num, numX, numY);
            }
        }
        
        // Draw statistics
        int statsY = padding + M * cellHeight + 30;
        g2d.setFont(new Font("Arial", Font.PLAIN, 14));
        g2d.drawString(String.format("Generation: %d", generation), padding, statsY);
        g2d.drawString(String.format("Cost: %.2f", cost), padding + 200, statsY);
        
        long elapsedTime = (System.currentTimeMillis() - startTime) / 1000;
        g2d.drawString(String.format("Time: %02d:%02d", elapsedTime / 60, elapsedTime % 60),
                      padding + 400, statsY);
    }
}
