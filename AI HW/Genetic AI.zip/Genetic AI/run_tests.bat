@echo off
echo Running Genetic Algorithm Test Cases...
echo.

REM Test Case 1: N = 4, M = 5
echo Running Test Case 1: N = 4, M = 5
java -cp bin com.ga.Main 5 4
echo Test Case 1 completed.
echo.

REM Test Case 2: N = 7, M = 13
echo Running Test Case 2: N = 7, M = 13
java -cp bin com.ga.Main 13 7
echo Test Case 2 completed.
echo.

REM Test Case 3: N = 37, M = 35
echo Running Test Case 3: N = 37, M = 35
java -cp bin com.ga.Main 35 37
echo Test Case 3 completed.
echo.

REM Test Case 4: N = 75, M = 100
echo Running Test Case 4: N = 75, M = 100
java -cp bin com.ga.Main 100 75
echo Test Case 4 completed.
echo.

REM Test Case 5: N = 490, M = 730
echo Running Test Case 5: N = 490, M = 730
java -cp bin com.ga.Main 730 490
echo Test Case 5 completed.
echo.

echo All test cases completed.
echo Results are saved in solution_*.txt files
pause 