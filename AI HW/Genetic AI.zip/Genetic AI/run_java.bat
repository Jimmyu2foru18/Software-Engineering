@echo off
cd java\src\main\java
javac -encoding UTF-8 com/ga/model/*.java com/ga/Main.java
java com.ga.Main
pause 