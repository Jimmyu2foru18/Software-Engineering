
let board;
let context;

const boardWidth = window.innerWidth;  
const boardHeight = window.innerHeight;

const rabbitWidth = 100;  
const rabbitHeight = 100; 
let rabbitX = boardWidth / 2 - rabbitWidth / 2;
let rabbitY = boardHeight * 3 / 8 - rabbitHeight;
let rabbitRightImg = new Image();
let rabbitLeftImg = new Image();
rabbitRightImg.src = "./rabbit-right.png";
rabbitLeftImg.src = "./rabbit-left.png";

let rabbit = {
    img: rabbitRightImg,
    x: rabbitX,
    y: rabbitY,
    width: rabbitWidth,
    height: rabbitHeight
};

let velocityX = 0;
let velocityY = 0; 
const initialVelocityY = -10;  
const gravity = 0.3;  

let platformArray = [];
const platformWidth = 450; 
const platformHeight = 250;   
let platformImg = new Image();
platformImg.src = "./platform.png";

let score = 0;
let maxScore = 0;
let gameOver = false;

// Start the game
function startGame() {
    document.getElementById("menu").style.display = "none";
    document.getElementById("gameOverScreen").style.display = "none"; 
    document.getElementById("board").style.display = "block";

    board = document.getElementById("board");
    board.height = boardHeight;
    board.width = boardWidth; 
    context = board.getContext("2d"); 

    velocityY = initialVelocityY;
    placePlatforms();
    requestAnimationFrame(update);
    document.addEventListener("keydown", moveRabbit);
}

// Update game state
function update() {
    requestAnimationFrame(update);
    
    if (gameOver) {
        document.getElementById("board").style.display = "none"; 
        document.getElementById("gameOverScreen").style.display = "block"; 
        document.getElementById("scoreDisplay").textContent = score; // Show the score on game over
        return;
    }

    context.clearRect(0, 0, board.width, board.height);

    // Update rabbit position
    rabbit.x += velocityX;
    if (rabbit.x > boardWidth) {
        rabbit.x = 0;
    } else if (rabbit.x + rabbit.width < 0) {
        rabbit.x = boardWidth;
    }

    velocityY += gravity;
    rabbit.y += velocityY;
    
    // Check for game over condition
    if (rabbit.y > board.height) {
        gameOver = true;
    }

    context.drawImage(rabbit.img, rabbit.x, rabbit.y, rabbit.width, rabbit.height);
    
    // Draw platforms and check for collisions
    for (let platform of platformArray) {
        if (velocityY < 0 && rabbit.y < boardHeight * 3 / 4) {
            platform.y -= initialVelocityY; // Move platform when rabbit jumps
        }

        if (detectCollision(rabbit, platform) && velocityY >= 0) {
            velocityY = initialVelocityY; // Reset velocity on collision
        }

        context.drawImage(platform.img, platform.x, platform.y, platform.width, platform.height);
    }

    // Remove platforms that have gone off screen and create new ones
    while (platformArray.length > 0 && platformArray[0].y >= boardHeight) {
        platformArray.shift(); 
        newPlatform(); 
    }

    updateScore();
    context.fillStyle = "black";
    context.font = "16px sans-serif";
    context.fillText("Score: " + score, 5, 20);
}

// Handle rabbit movement
function moveRabbit(e) {
    switch (e.code) {
        case "ArrowRight":
        case "KeyD":
            velocityX = 9;
            rabbit.img = rabbitRightImg;
            break;
        case "ArrowLeft":
        case "KeyA": 
            velocityX = -9; 
            rabbit.img = rabbitLeftImg;
            break;
        case "Space":
            if (gameOver) resetGame();
            break;
    }
}

// Reset game state
function resetGame() {
    rabbit = {
        img: rabbitRightImg,
        x: rabbitX,
        y: rabbitY,
        width: rabbitWidth,
        height: rabbitHeight
    };

    velocityX = 0;
    velocityY = initialVelocityY;
    score = 0;
    maxScore = 0;
    gameOver = false; 
    document.getElementById("gameOverScreen").style.display = "none"; 
    document.getElementById("board").style.display = "block"; 
    placePlatforms();
}

// Place initial platforms
function placePlatforms() {
    platformArray = [];
    
    const verticalSpacing = rabbitHeight; // Adjusting vertical spacing to match the rabbit height
    
    // Create the base platform
    platformArray.push({
        img: platformImg,
        x: boardWidth / 2,
        y: boardHeight - 50,
        width: platformWidth,
        height: platformHeight
    });

    // Create additional platforms
    for (let i = 1; i < 6; i++) {
        let randomX = Math.floor(Math.random() * (boardWidth - platformWidth));
        platformArray.push({
            img: platformImg,
            x: randomX,
            y: boardHeight - verticalSpacing * i - platformHeight + 5, // Minor offset for better alignment
            width: platformWidth,
            height: platformHeight
        });
    }
}

// Create a new platform
function newPlatform() {
    let lastPlatformY = platformArray[platformArray.length - 1].y; 
    let randomX = Math.floor(Math.random() * (boardWidth - platformWidth));
    
    platformArray.push({
        img: platformImg,
        x: randomX,
        y: lastPlatformY - platformHeight, // Aligning directly above the last platform
        width: platformWidth,
        height: platformHeight
    });
}

// Detect collision between two objects
function detectCollision(a, b) {
    return a.x < b.x + b.width &&  
           a.x + a.width > b.x &&  
           a.y < b.y + b.height && 
           a.y + a.height > b.y;  
}

// Update score based on rabbit's movement
function updateScore() {
    let points = Math.floor(50 * Math.random()); 
    if (velocityY < 0) {
        maxScore += points;
        if (score < maxScore) {
            score = maxScore;
        }
    } else if (velocityY >= 0) {
        maxScore -= points;
    }
}

// Event listeners for buttons
document.getElementById("playButton").addEventListener("click", startGame);
document.getElementById("restartButton").addEventListener("click", resetGame);
