// Flappy Cheese Game in Processing

int cheeseY;
float gravity = 0.4;  // Decreased gravity for a more Flappy Bird-like feel
float lift = -8;       // Increased lift for a more pronounced jump
float velocity = 0;
int score = 0;
ArrayList<Pipe> pipes;
int pipeWidth = 60;
float cheeseSize = 30; // Initial size of the cheese
boolean gameOver = false;
float lastPipeTime = 0; // To track time for pipe generation
float pipeInterval = 2; // Time interval for new pipe (in seconds)
int minGap = 100;       // Minimum gap between pipes
int maxGap = 200;       // Maximum gap between pipes
int gap;                // Current gap size

void setup() {
  size(400, 600);
  cheeseY = height / 2;
  pipes = new ArrayList<Pipe>();
  gap = maxGap; // Start with maximum gap
  pipes.add(new Pipe(gap));
}

void draw() {
  background(135, 206, 235); // Sky blue
  
  if (!gameOver) {
    // Apply gravity
    velocity += gravity;
    cheeseY += velocity;

    // Check for collision with the ground or ceiling
    if (cheeseY > height) {
      cheeseY = height;  // Prevent going below the ground
      velocity = 0;      // Reset velocity on ground hit
      gameOver = true;
    } else if (cheeseY < 0) {
      cheeseY = 0;       // Prevent going above the screen
      velocity = 0;      // Reset velocity on ceiling hit
      gameOver = true;
    }

    // Move and draw pipes
    for (int i = pipes.size() - 1; i >= 0; i--) {
      Pipe p = pipes.get(i);
      p.update();
      p.show();

      // Check for collision
      if (p.hits(cheeseY, cheeseSize)) {
        shrinkCheese(); // Shrink the cheese on collision
        gameOver = true;
      }

      // Remove off-screen pipes
      if (p.isOffScreen()) {
        pipes.remove(i);
        score++;
        growCheese(); // Grow the cheese when passing a pipe
        adjustGap();  // Adjust the gap size based on score
      }
    }

    // Add new pipes every 2 seconds
    if (millis() - lastPipeTime > pipeInterval * 1000) {
      pipes.add(new Pipe(gap));
      lastPipeTime = millis(); // Reset the last pipe time
    }

    // Draw the cheese (cheese wedge shape)
    fill(255, 255, 0); // Yellow cheese
    drawCheese(100, cheeseY, cheeseSize);
    
    // Draw the score
    fill(0);
    textSize(32);
    text(score, 10, 30);
  } else {
    fill(0);
    textSize(48);
    text("Game Over", 100, height / 2);
    textSize(32);
    text("Score: " + score, 120, height / 2 + 50);
  }
}

void keyPressed() {
  if (!gameOver) {
    if (key == ' ') {
      velocity += lift; // Jump with inertia
    }
  } else {
    resetGame();
  }
}

void resetGame() {
  cheeseY = height / 2;
  velocity = 0; // Reset velocity
  score = 0;
  cheeseSize = 30; // Reset cheese size
  pipes.clear();
  gap = maxGap; // Reset gap to max
  pipes.add(new Pipe(gap));
  lastPipeTime = millis(); // Reset the timer for new pipes
  gameOver = false;
}

// Function to draw cheese in a wedge shape
void drawCheese(float x, float y, float size) {
  beginShape();
  vertex(x - size / 2, y + size / 2); // Bottom left
  vertex(x + size / 2, y + size / 2); // Bottom right
  vertex(x + size * 0.33, y - size * 0.33); // Top right
  vertex(x - size * 0.33, y - size * 0.33); // Top left
  endShape(CLOSE);
}

// Function to grow the cheese
void growCheese() {
  cheeseSize += 5; // Increase the size
  if (cheeseSize > 60) { // Cap the maximum size
    cheeseSize = 60;
  }
}

// Function to shrink the cheese
void shrinkCheese() {
  cheeseSize -= 5; // Decrease the size
  if (cheeseSize < 10) { // Cap the minimum size
    cheeseSize = 10;
  }
}

// Function to adjust the gap based on score
void adjustGap() {
  if (score % 5 == 0) { // Adjust gap every 5 points
    gap = constrain(gap - 5, minGap, maxGap); // Decrease the gap
  }
}

class Pipe {
  float x;
  float top;
  float bottom;
  
  Pipe(int gap) {
    x = width;
    top = random(50, height - gap - 50);
    bottom = height - (top + gap);
  }

  void update() {
    x -= 3; // Speed of the pipes
  }

  void show() {
    fill(34, 139, 34); // Green pipes
    rect(x, 0, pipeWidth, top);
    rect(x, height - bottom, pipeWidth, bottom);
  }

  boolean hits(int cheeseY, float cheeseSize) {
    return (cheeseY < top || cheeseY > height - bottom) && (x < 100 + cheeseSize / 2 && x + pipeWidth > 100 - cheeseSize / 2);
  }

  boolean isOffScreen() {
    return x < -pipeWidth;
  }
}
