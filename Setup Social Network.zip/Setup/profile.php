<?php
$servername = "localhost";
$username = "root";
$password = "Slycooper20!";
$dbname = "social_network";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$userId = $_GET['userId'];

$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

$stmt = $conn->prepare("SELECT * FROM posts WHERE user_id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$posts = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="profile-container">
        <h1><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></h1>
        <img src="uploads/<?php echo $user['profile_pic']; ?>" alt="Profile Picture">
        <h2>Posts</h2>
        <?php while ($post = $posts->fetch_assoc()) { ?>
            <div class="post">
                <p><?php echo $post['content']; ?></p>
            </div>
        <?php } ?>
    </div>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
