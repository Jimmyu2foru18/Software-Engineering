import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

class GamePanel extends JPanel implements KeyListener {
    private Player player;
    private ArrayList<Obstacle> obstacles;
    private ArrayList<Fruit> fruits;
    private int score;

    public GamePanel() {
        setBackground(Color.CYAN);
        setFocusable(true);
        addKeyListener(this);
        
        player = new Player();
        obstacles = new ArrayList<>();
        fruits = new ArrayList<>();
        score = 0;

        // Example obstacles and fruits
        obstacles.add(new Obstacle(300, 450));
        fruits.add(new Fruit(500, 400));
    }

    public void update() {
        player.update();
        for (Obstacle obstacle : obstacles) {
            if (player.getBounds().intersects(obstacle.getBounds())) {
                // Handle collision (e.g., reset the game)
                System.out.println("Hit an obstacle!");
                // You might want to implement a game over or health system
            }
        }
        for (int i = 0; i < fruits.size(); i++) {
            Fruit fruit = fruits.get(i);
            if (player.getBounds().intersects(fruit.getBounds())) {
                score++;
                fruits.remove(i); // Collect fruit
                break;
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        player.draw(g);
        for (Obstacle obstacle : obstacles) {
            obstacle.draw(g);
        }
        for (Fruit fruit : fruits) {
            fruit.draw(g);
        }
        g.drawString("Score: " + score, 10, 20);
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            player.jump();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {}
    @Override
    public void keyTyped(KeyEvent e) {}
}
