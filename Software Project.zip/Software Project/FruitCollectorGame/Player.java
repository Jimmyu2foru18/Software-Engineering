import java.awt.*;

class Player {
    private int x, y, width, height;
    private int dy; // Change in y (for jumping)
    private boolean jumping;

    public Player() {
        x = 100;
        y = 450; // Ground level
        width = 50;
        height = 50;
        dy = 0;
        jumping = false;
    }

    public void update() {
        if (jumping) {
            dy += 1; // Gravity
            y += dy;

            if (y >= 450) { // Ground level
                y = 450;
                jumping = false;
                dy = 0;
            }
        }
    }

    public void jump() {
        if (!jumping) {
            dy = -15; // Jump force
            jumping = true;
        }
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, width, height);
    }

    public void draw(Graphics g) {
        g.setColor(Color.RED);
        g.fillRect(x, y, width, height);
    }
}
