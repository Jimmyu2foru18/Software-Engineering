import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FruitCollectorGame extends JFrame implements ActionListener {
    private Timer timer;
    private GamePanel gamePanel;

    public FruitCollectorGame() {
        setTitle("Fruit Collector Game");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        
        gamePanel = new GamePanel();
        add(gamePanel);
        
        timer = new Timer(16, this); // ~60 FPS
        timer.start();
        
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        gamePanel.update();
        gamePanel.repaint();
    }

    public static void main(String[] args) {
        new FruitCollectorGame();
    }
}
