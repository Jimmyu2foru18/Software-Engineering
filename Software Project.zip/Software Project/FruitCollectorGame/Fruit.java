import java.awt.*;

class Fruit {
    private int x, y, width, height;

    public Fruit(int x, int y) {
        this.x = x;
        this.y = y;
        this.width = 30;
        this.height = 30;
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, width, height);
    }

    public void draw(Graphics g) {
        g.setColor(Color.YELLOW);
        g.fillOval(x, y, width, height);
    }
}
